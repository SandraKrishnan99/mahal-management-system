from django.apps import AppConfig


class MahalAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Mahal_app'
