from django.shortcuts import render
from .models import  user_register_table,birth_register_table,death_register_table,marriage_register_table,divorce_register_table,madrasa_register_table,family_register_table
from .models import accounts_table,comm_byhouse_table,comm_bypeople_table,member1_table,minute_table,mahallu_account_table
from .models import  madrasa_account_table,complaint_table,property_table,rental_table,staffreg_table,studentreg_table,mark_table,resulttable
def index(request):
    return render(request,"index.html")

def user_signup(request):
    return render(request,"user_signup.html")

def user_signup_save(request):
    if request.method=="POST":
        a=user_register_table()
        a.name=request.POST.get("name")
        a.address=request.POST.get("address")
        a.gender=request.POST.get("gender")
        a.email=request.POST.get("email")
        a.phone=request.POST.get("phn")
        a.username=request.POST.get("uname")
        a.password=request.POST.get("pswd")
        a.save()
        return render(request,"login.html")
def login(request):
    return render(request,"login.html")

def login_save(request):
    if request.method=="POST":
        username=request.POST.get("uname")
        password=request.POST.get("pass")
        if(user_register_table.objects.filter(username=username,password=password).exists()):
            user=user_register_table.objects.get(username=username,password=password)
            request.session['user_name']=user.username
            request.session['user_id']=user.id
            return render(request,"user_home.html")
        elif(username=="admin" and password=="admin"):
            return render(request,"admin_home.html")
        elif(username=="madrasa" and password=="madrasa"):
            return render(request,"madrasa_home.html")

def idcard1(request):
    return render(request,"idcard.html")

def idcard2(request):
    return render(request,"idsreport.html")

def family_register(request):
    return render(request,"family_register.html")

def birth_register(request):
    return render(request,"birth_register.html")

def birth_reg_save(request):
    if request.method=="POST":
        b=birth_register_table()
        b.childname=request.POST.get("cname")
        b.gender=request.POST.get("gender")
        b.birthdate=request.POST.get("bdate")
        b.birthplace=request.POST.get("bplace")
        b.mothername=request.POST.get("mname")
        b.fathername=request.POST.get("fname")
        b.address=request.POST.get("address")
        b.pmc=request.POST.get("pmc")
        b.save()
        return render(request,"user_home.html")

def death_register(request):
    return render(request,"death_register.html")

def death_reg_save(request):
    if request.method=="POST":
        c=death_register_table()
        c.name=request.POST.get("name")
        c.gender=request.POST.get("gender")
        c.age=request.POST.get("age")
        c.deathdate=request.POST.get("ddate")
        c.deathplace=request.POST.get("dplace")
        c.address=request.POST.get("address")
        c.pmc=request.POST.get("pmc")
        c.save()
        return render(request,"user_home.html")
def  marriage_register(request):
    return render(request,"marriage_register.html")

def marriage_reg_save(request):
    if request.method=="POST":
        d=marriage_register_table()
        d.husbandname=request.POST.get("hname")
        d.hdob=request.POST.get("bhdate")
        d.hage=request.POST.get("hage")
        d.wifename=request.POST.get("wname")
        d.wdob=request.POST.get("bwdate")
        d.wage=request.POST.get("wage")
        d.marriagedate=request.POST.get("mdate")
        d.marriageplace=request.POST.get("mplace")
        d.husbandname=request.POST.get("hname")
        d.save()
        return render(request,"user_home.html")

def divorce_register(request):
    return render(request,"divorce_register.html")


def divorce_reg_save(request):
    if request.method=="POST":
        e=divorce_register_table()
        e.husbandname=request.POST.get("hname")
        e.hage=request.POST.get("hage")
        e.wifename=request.POST.get("wname")
        e.wage=request.POST.get("wage")
        e.marriagedate=request.POST.get("mdate")
        e.reason=request.POST.get("resn")
        e.save()
        return render(request,"user_home.html")
def logout(request):
    return render(request,"index.html")

def madrasa_register(request):
    return render(request,"madrasa_register.html")

def madrasa_reg_save(request):
    if request.method=="POST":
        f=madrasa_register_table()
        f.childname=request.POST.get("cname")
        f.gender=request.POST.get("gender")
        f.classs=request.POST.get("cls")
        f.birthdate=request.POST.get("bdate")
        f.parentname=request.POST.get("pname")
        f.address=request.POST.get("address")
        f.save()
        return render(request,"user_home.html")

def family_reg_save(request):
    if request.method=="POST":
        g=family_register_table()
        g.name=request.POST.get("name")
        g.address=request.POST.get("address")
        g.pmc=request.POST.get("pmc")
        g.totalmembers=request.POST.get("tmem")
        g.save()
        return render(request,"user_home.html")

def admin_view_family(request):
    obj1=family_register_table.objects.all()
    return render(request,"admin_view_family.html",{'fdata':obj1})

def admin_comitte_family(request):
    obj15=member1_table.objects.all()
    return render(request,"admin_view_family.html",{'medata':obj15})

def admin_view_birthdetail(request):
    obj2=birth_register_table.objects.all()
    return render(request,"admin_view_birthdetail.html",{'birthdata':obj2})


def admin_view_deathdetail(request):
    obj3=death_register_table.objects.all()
    return render(request,"admin_view_deathdetail.html",{'deathdata':obj3})

def admin_view_mrgedetail(request):
    obj4=marriage_register_table.objects.all()
    return render(request,"admin_view_mrgedetail.html",{'mrgedata':obj4})

def admin_view_divorcedetail(request):
    obj5=divorce_register_table.objects.all()
    return render(request,"admin_view_divorcedetail.html",{'dvdata':obj5})

def admin_view_madrasadetail(request):
    obj6=madrasa_register_table.objects.all()
    return render(request,"admin_view_madrasadetail.html",{'mddata':obj6})

def admin_view_accounts(request):
    obj7=accounts_table.objects.all()
    mdra=madrasa_account_table.objects.all()
    ml=mahallu_account_table.objects.all()

    return render(request,"admin_view_accounts.html",{'acdata':obj7,'mdra':mdra,'ml':ml})


def admin_committe(request):
    ac=member1_table.objects.all()
    cmt=complaint_table.objects.all()
    return render(request,"admin_committe.html",{'acdata':ac,'cmt':cmt})
def admin_committe_reg(request):
    return render(request,"admin_committe_reg.html")


def comreg_byhouse(request):
    return render(request,"comreg_byhouse.html")

def comreg_byhouse_save(request):
    if request.method=="POST":
        cb=comm_byhouse_table()
        cb.housename=request.POST.get("hname")
        cb.owner=request.POST.get("onr")
        cb.buildingno=request.POST.get("bno")
        cb.save()
        return render(request,"admin_committe.html")

def comreg_bypeople(request):
    return render(request,"comreg_bypeople.html")

def comreg_bypeople_save(request):
    if request.method=="POST":
        cp=comm_bypeople_table()
        cp.name=request.POST.get("name")
        cp.address=request.POST.get("adrs")
        cp.buildingno=request.POST.get("bno")
        cp.save()
        return render(request,"admin_committe.html")
def admin_committe_view(request):
    return render(request,"admin_committe.html")


def admin_committe_reg_view(request):
    return render(request,"admin_committe_reg_view.html")


def comreg_view_byhouse(request):
    hv=comm_byhouse_table.objects.all()
    return render(request,"comreg_view_byhouse.html",{'hv':hv})


def comreg_view_bypeople(request):
    pv=comm_bypeople_table.objects.all()
    return render(request,"comreg_view_bypeople.html",{'pv':pv})


def admin_home(request):
    return render(request,"admin_home.html")

def committe_account(request):
    obj8=accounts_table.objects.all()
    return render(request,"committe_account.html",{'cmdata':obj8})

def meeting_save(request):
    if request.method=="POST":
        mc=minute_table()
        mc.mcc=request.POST.get("mett")
        mc.fcc=request.POST.get("facc")
        mc.ncc=request.POST.get("natt")
        mc.dcc=request.POST.get("des")
        mc.acc=request.POST.get("att")
        mc.save()
        return render(request,"admin_committe.html")

def minut_view(request):
    mnv=minute_table.objects.all()
    return render(request,"admin_committe.html",{'mnv':mnv})


def mahallu_account_save(request):
    if request.method=="POST":
        ma=mahallu_account_table()
        ma.staff=request.POST.get("stf")
        ma.month=request.POST.get("mnt")
        ma.salary=request.POST.get("slry")
        ma.cbill=request.POST.get("cbill")
        ma.save()
        return render(request,"admin_view_accounts.html")
def admin_view_proprttyrenatl(request):
    prv=property_table.objects.all()

    return render(request,"admin_view_proprttyrenatl.html",{'prv':prv})


def property_save(request):
    if request.method=="POST":
        pr=property_table()
        pr.property=request.POST.get("prt")
        pr.type=request.POST.get("type")
        pr.pbnno=request.POST.get("pbn")
        pr.date=request.POST.get("dte")
        pr.save()
        return render(request,"admin_view_proprttyrenatl.html")


def rental_save(request):
    if request.method=="POST":
        rn=rental_table()
        rn.rental=request.POST.get("rntl")
        rn.type=request.POST.get("type")
        rn.ramount=request.POST.get("ram")
        rn.date=request.POST.get("dte")
        rn.save()
        return render(request,"admin_view_proprttyrenatl.html")


def staff_register(request):
    return render(request,"staff_register.html")

def staff_reg_save(request):
    if request.method=="POST":
        stf=staffreg_table()
        stf.staffname=request.POST.get("stfname")
        stf.staffid=request.POST.get("stfid")
        stf.staffemail=request.POST.get("stfemail")
        stf.address=request.POST.get("adrs")
        stf.save()
        return render(request,"user_home.html")


def student_register(request):
    return render(request,"student_register.html")

def student_reg_save(request):
    if request.method=="POST":
        str=studentreg_table()
        str.studentname=request.POST.get("stuname")
        str.age=request.POST.get("stage")
        str.email=request.POST.get("stuemail")
        str.address=request.POST.get("adrs")
        str.save()
        return render(request,"user_home.html")
def exam(request):
    return render(request,"exam.html")

def student_mark(request):
    return render(request,"student_mark.html")

def student_mark_save(request):
    if request.method=="POST":
        mrk=mark_table()
        mrk.studentname=request.POST.get("stuname")
        mrk.mark=request.POST.get("mark")
        mrk.save()
        return render(request,"user_home.html")

def student_result(request):
    return render(request,"student_result.html")


def student_result_save(request):
    if request.method=="POST":
        res=resulttable()
        res.studentname=request.POST.get("stuname")
        res.result=request.POST.get("reslt")
        res.save()
        return render(request,"user_home.html")


def admin_view_staffdetail(request):
    avs=staffreg_table.objects.all()
    return render(request,"admin_view_staffdetail.html",{'avs':avs})


def admin_view_studentdetail(request):
    avstu=studentreg_table.objects.all()
    return render(request,"admin_view_studentdetail.html",{'avstu':avstu})