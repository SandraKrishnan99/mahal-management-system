from django.contrib import admin
from .models import madrasa_register_table,accounts_table,member1_table,madrasa_account_table,complaint_table,studentreg_table
admin.site.register(madrasa_register_table)
admin.site.register(accounts_table)
admin.site.register(member1_table)
admin.site.register(madrasa_account_table)
admin.site.register(complaint_table)
admin.site.register(studentreg_table)
# Register your models here.
